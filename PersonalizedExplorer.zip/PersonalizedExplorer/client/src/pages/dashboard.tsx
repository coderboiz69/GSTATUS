import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GraduationCap, Home, Settings, Trophy, History } from "lucide-react";
import HomeTab from "@/components/tabs/home-tab";
import AdministrationTab from "@/components/tabs/administration-tab";
import RankingsTab from "@/components/tabs/rankings-tab";
import ResponsesTab from "@/components/tabs/responses-tab";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-white w-10 h-10 rounded-lg flex items-center justify-center">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-900">GSTATUS</h1>
                <p className="text-sm text-slate-600">Gurukul Points Management</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-slate-600">System Active</span>
              </div>
              <div className="flex items-center space-x-2 bg-slate-100 px-3 py-1 rounded-full">
                <div className="w-6 h-6 bg-slate-400 rounded-full flex items-center justify-center">
                  <span className="text-xs text-white">A</span>
                </div>
                <span className="text-sm text-slate-700">Admin</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="home" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white border border-slate-200 p-1 rounded-lg">
            <TabsTrigger value="home" className="flex items-center space-x-2">
              <Home className="w-4 h-4" />
              <span>Home</span>
            </TabsTrigger>
            <TabsTrigger value="administration" className="flex items-center space-x-2">
              <Settings className="w-4 h-4" />
              <span>Administration</span>
            </TabsTrigger>
            <TabsTrigger value="rankings" className="flex items-center space-x-2">
              <Trophy className="w-4 h-4" />
              <span>Rankings</span>
            </TabsTrigger>
            <TabsTrigger value="responses" className="flex items-center space-x-2">
              <History className="w-4 h-4" />
              <span>Responses</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="home" className="mt-8">
            <HomeTab />
          </TabsContent>

          <TabsContent value="administration" className="mt-8">
            <AdministrationTab />
          </TabsContent>

          <TabsContent value="rankings" className="mt-8">
            <RankingsTab />
          </TabsContent>

          <TabsContent value="responses" className="mt-8">
            <ResponsesTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
