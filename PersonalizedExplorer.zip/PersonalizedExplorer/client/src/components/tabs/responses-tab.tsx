import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import type { Action, Student } from "@shared/schema";

type ActionWithStudent = Action & { student: Student };

export default function ResponsesTab() {
  const { data: actions, isLoading } = useQuery({
    queryKey: ["/api/actions"],
    queryFn: async () => {
      const response = await fetch("/api/actions");
      if (!response.ok) throw new Error("Failed to fetch actions");
      return response.json() as Promise<ActionWithStudent[]>;
    },
  });

  const getPointsBadgeColor = (points: number) => {
    return points > 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Response History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Student</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Points</TableHead>
                <TableHead>Admin</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-48" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                  </TableRow>
                ))
              ) : actions && actions.length > 0 ? (
                actions.map((action) => (
                  <TableRow key={action.id} className="hover:bg-slate-50">
                    <TableCell>
                      <div>
                        <div className="text-sm text-slate-900">
                          {format(new Date(action.createdAt), "MMM dd, yyyy")}
                        </div>
                        <div className="text-sm text-slate-500">
                          {format(new Date(action.createdAt), "h:mm a")}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium text-slate-900">{action.student.name}</div>
                        <div className="text-sm text-slate-500">{action.student.studentId}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-900">{action.action}</TableCell>
                    <TableCell>
                      <Badge className={getPointsBadgeColor(action.pointsChanged)}>
                        {action.pointsChanged > 0 ? "+" : ""}{action.pointsChanged}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-slate-500">{action.adminName}</TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-slate-500">
                    No actions recorded yet
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
