import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function HomeTab() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* System Status Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">System Status</CardTitle>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-slate-600">Status:</span>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Active
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Version:</span>
              <span className="text-slate-900">2.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Last Updated:</span>
              <span className="text-slate-900">2 minutes ago</span>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {isLoading ? (
              <>
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
              </>
            ) : (
              <>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Students:</span>
                  <span className="text-slate-900 font-medium">{stats?.totalStudents || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Active Students:</span>
                  <span className="text-slate-900 font-medium">{stats?.activeStudents || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Today's Actions:</span>
                  <span className="text-slate-900 font-medium">{stats?.todayActions || 0}</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm text-slate-900">System initialized</p>
                <p className="text-xs text-slate-500">Just now</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm text-slate-900">Students data loaded</p>
                <p className="text-xs text-slate-500">1 minute ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm text-slate-900">Database connected</p>
                <p className="text-xs text-slate-500">2 minutes ago</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Welcome Message */}
      <div className="bg-gradient-to-r from-primary to-blue-600 rounded-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Jai Swaminarayan</h2>
        <p className="text-blue-100">
          Welcome to the Gurukul Points Management System. Manage student points efficiently and track their progress.
        </p>
      </div>
    </div>
  );
}
