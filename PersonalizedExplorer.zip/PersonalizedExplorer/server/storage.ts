import { students, actions, type Student, type InsertStudent, type Action, type InsertAction, type UpdatePointsRequest } from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, ilike, or, and } from "drizzle-orm";

export interface IStorage {
  // Student operations
  getAllStudents(): Promise<Student[]>;
  getStudentById(id: number): Promise<Student | undefined>;
  getStudentByStudentId(studentId: string): Promise<Student | undefined>;
  searchStudents(query: string): Promise<Student[]>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;
  
  // Points operations
  updateStudentPoints(data: UpdatePointsRequest): Promise<{ student: Student; action: Action }>;
  
  // Actions operations
  getAllActions(): Promise<(Action & { student: Student })[]>;
  getActionsByStudentId(studentId: number): Promise<Action[]>;
  
  // Rankings operations
  getStudentRankings(gradeFilter?: string, floorFilter?: string): Promise<Student[]>;
  
  // Bulk operations
  initializeStudentsFromData(studentsData: any[]): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(students).orderBy(asc(students.name));
  }

  async getStudentById(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async getStudentByStudentId(studentId: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.studentId, studentId));
    return student;
  }

  async searchStudents(query: string): Promise<Student[]> {
    const searchTerm = `%${query}%`;
    return await db.select().from(students).where(
      or(
        ilike(students.name, searchTerm),
        ilike(students.studentId, searchTerm),
        ilike(students.room, searchTerm),
        ilike(students.floor, searchTerm)
      )
    ).orderBy(asc(students.name));
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  async updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined> {
    const [updatedStudent] = await db
      .update(students)
      .set({ ...student, updatedAt: new Date() })
      .where(eq(students.id, id))
      .returning();
    return updatedStudent;
  }

  async deleteStudent(id: number): Promise<boolean> {
    const result = await db.delete(students).where(eq(students.id, id));
    return result.rowCount > 0;
  }

  async updateStudentPoints(data: UpdatePointsRequest): Promise<{ student: Student; action: Action }> {
    const student = await this.getStudentById(data.studentId);
    if (!student) {
      throw new Error("Student not found");
    }

    const newPoints = student.points + data.pointsChanged;
    const newGrade = this.calculateGrade(newPoints);

    // Update student points and grade
    const [updatedStudent] = await db
      .update(students)
      .set({ 
        points: newPoints, 
        grade: newGrade,
        updatedAt: new Date()
      })
      .where(eq(students.id, data.studentId))
      .returning();

    // Create action record
    const [action] = await db
      .insert(actions)
      .values({
        studentId: data.studentId,
        action: data.action,
        pointsChanged: data.pointsChanged,
        actionType: data.actionType,
        adminName: "Admin"
      })
      .returning();

    return { student: updatedStudent, action };
  }

  async getAllActions(): Promise<(Action & { student: Student })[]> {
    const result = await db
      .select()
      .from(actions)
      .leftJoin(students, eq(actions.studentId, students.id))
      .orderBy(desc(actions.createdAt));
    
    return result.map(row => ({
      ...row.actions,
      student: row.students!
    }));
  }

  async getActionsByStudentId(studentId: number): Promise<Action[]> {
    return await db
      .select()
      .from(actions)
      .where(eq(actions.studentId, studentId))
      .orderBy(desc(actions.createdAt));
  }

  async getStudentRankings(gradeFilter?: string, floorFilter?: string): Promise<Student[]> {
    let query = db.select().from(students);
    
    const conditions = [];
    
    if (gradeFilter && gradeFilter !== 'all') {
      conditions.push(eq(students.grade, gradeFilter));
    }
    
    if (floorFilter && floorFilter !== 'all') {
      conditions.push(eq(students.floor, floorFilter));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(desc(students.points), asc(students.name));
  }

  async initializeStudentsFromData(studentsData: any[]): Promise<void> {
    // Check if students already exist
    const existingStudents = await db.select().from(students).limit(1);
    if (existingStudents.length > 0) {
      return; // Already initialized
    }

    // Insert students in batches
    const batchSize = 100;
    for (let i = 0; i < studentsData.length; i += batchSize) {
      const batch = studentsData.slice(i, i + batchSize);
      const formattedBatch = batch.map(student => ({
        studentId: student.id,
        name: student.name,
        room: student.room,
        floor: student.floor,
        points: student.points || 0,
        grade: this.calculateGrade(student.points || 0),
        remark: student.remark || '',
        active: student.active !== false
      }));
      
      await db.insert(students).values(formattedBatch);
    }
  }

  private calculateGrade(points: number): string {
    if (points >= 80) return 'A+';
    if (points >= 60) return 'A';
    if (points >= 40) return 'B';
    if (points >= 20) return 'C';
    return 'D';
  }
}

export const storage = new DatabaseStorage();
